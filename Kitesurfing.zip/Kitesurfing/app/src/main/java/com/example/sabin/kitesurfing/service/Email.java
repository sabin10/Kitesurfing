package com.example.sabin.kitesurfing.service;

public class Email {
    final String email;

    public Email(String email) {
        this.email = email;
    }
}
