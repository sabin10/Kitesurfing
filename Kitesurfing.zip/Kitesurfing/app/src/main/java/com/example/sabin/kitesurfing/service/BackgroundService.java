package com.example.sabin.kitesurfing.service;

import android.app.IntentService;
import android.content.Intent;
import android.util.Log;

public class BackgroundService extends IntentService {
    public BackgroundService() {
        super("BackgroundService");
    }

    @Override
    protected void onHandleIntent(@androidx.annotation.Nullable Intent intent) {

    }
}
